module.exports = {
    images: {
      domains: ['randomuser.me'],
    },
  }